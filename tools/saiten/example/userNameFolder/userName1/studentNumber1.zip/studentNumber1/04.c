#include <stdio.h>

int main() {
    printf("4\n");
    return 0;
}