#include <stdio.h>

int main() {
    printf("3\n");
    return 0;
}