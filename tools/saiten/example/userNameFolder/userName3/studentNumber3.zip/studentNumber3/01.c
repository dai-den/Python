#include <stdio.h>
#include <math.h>

int main() {
    printf("1\n");
    printf("%lf\n",sin(90));
    return 0;
}